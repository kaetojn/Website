<?php

class CreateTableDemo {

    /**
     * database host
     */
    const DB_HOST = 'www.cooeeuas.com';

    /**
     * database name
     */
    const DB_NAME = 'cooeeuas_actiontracker';

    /**
     * database user
     */
    const DB_USER = 'cooeeuas_npeppas';
    /*
     * database password
     */
    const DB_PASSWORD = 'Npep8338AL';

    /**
     *
     * @var type 
     */
    private $pdo = null;

    /**
     * Open the database connection
     */
    public function __construct() {
        // open database connection
        $conStr = sprintf("mysql:host=%s;dbname=%s", self::DB_HOST, self::DB_NAME);
        try {
            $this->pdo = new PDO($conStr, self::DB_USER, self::DB_PASSWORD);
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    /**
     * close the database connection
     */
    public function __destruct() {
        // close the database connection
        $this->pdo = null;
    }

    /**
     * create the tasks table
     * @return boolean returns true on success or false on failure
     */
    public function createTaskTable() {
        $sql = <<<EOSQL
            CREATE TABLE IF NOT EXISTS pbs (
                id     INT AUTO_INCREMENT PRIMARY KEY,
                parent_id     INT(4)        DEFAULT NULL,
                name VARCHAR (2)        NOT NULL
            );
EOSQL;
        return $this->pdo->exec($sql);
    }

}

// create tasks table
$obj = new CreateTableDemo();
$obj->createTaskTable();
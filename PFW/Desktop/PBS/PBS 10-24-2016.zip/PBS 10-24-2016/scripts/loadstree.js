$(document).ready(function() {
  $('#container1').jstree({
  "plugins" : ["contextmenu", "grid", "dnd", "wholerow", "state"],
  'core' : {
  	"check_callback" : true,
	"themes": {"default" : true, "dots" : true},   
	"multiple" : false,
	'data' : {
        	"url" : "read.php",
        	"dataType" : "JSON",
        }},
	"grid": {
        "columns": [{"width": 400, "header": "Product", "title": "_DATA_"},
        			{"width": 60, "cellClass": "col1", "value": "UID", "header": "CIUID", "title":"Other", "valueClass": "spanclass"},
        			{"width": 80, "cellClass": "col1", "value": "size", "header": "Size", "title":"Other", "valueClass": "spanclass"}],
        "resizable":true,
		"draggable":true,
        "height": 10
    },
    "contextmenu":{         
	    "items": function($node) {
	        var tree = $("#container1").jstree(true);
	        return {
	            "Create": {
	                "separator_before": false,
	                "separator_after": false,
	                "label": "Create",
	                "action": function (obj) { 
	                    $node = tree.create_node($node);
	                    tree.edit($node);
	                }
	            },
	            "Rename": {
	                "separator_before": false,
	                "separator_after": false,
	                "label": "Rename",
	                "action": function (obj) { 
	                    tree.edit($node);
	                }
	            },
	            "Nick Rules": {
	                "separator_before": false,
	                "separator_after": false,
	                "label": "Nick Rules",
	                "action": function (obj) { 
	                    tree.rename_node($node, 'Nick Rules');
	                }
	            },                         
	            "Remove": {
	                "separator_before": false,
	                "separator_after": false,
	                "label": "Remove",
	                "action": function (obj) { 
	                    tree.delete_node($node);
	                }
	            }
	        };
	    }
	}
  });
});
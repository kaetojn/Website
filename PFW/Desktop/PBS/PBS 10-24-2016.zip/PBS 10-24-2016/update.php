<?php

$connection = mysqli_connect("www.cooeeuas.com","cooeeuas_npeppas","Npep8338AL","cooeeuas_actiontracker") or die("Error " . mysqli_error($connection));

$test = $_POST["data"];
$obj = json_decode($test, true);
$data = $obj["myarray"];
var_dump($data);

$sql2 = "DELETE FROM pbs";
$connection ->query($sql2);

foreach($data as $val){
    $sql = "INSERT INTO pbs(id,parent,text) VALUES('".$val['id']."', '".$val['parent']."', '".$val['text']."')";
    $result = mysqli_query($connection, $sql) or die("Error in Selecting " . mysqli_error($connection));
}


mysqli_close($connection);

?> 
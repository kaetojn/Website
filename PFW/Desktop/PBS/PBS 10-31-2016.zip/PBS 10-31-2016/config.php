<?php
   define('DB_SERVER', 'www.cooeeuas.com');
   define('DB_USERNAME', 'cooeeuas_npeppas');
   define('DB_PASSWORD', 'Npep8338AL');
   define('DB_DATABASE', 'cooeeuas_actiontracker');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>
<?php
include('adminsession.php');
$connection = mysqli_connect("www.cooeeuas.com","cooeeuas_npeppas","Npep8338AL","cooeeuas_actiontracker") or die("Error " . mysqli_error($connection));

$test = $_POST["data"];
$obj = json_decode($test, true);
$data = $obj["myarray"];

$ids_array4 = array();
$ids_array3 = array();
$ids_array2 = array();
$ids_array1 = array();


foreach($data as $val){

   $ids_array3[] = $val["id"];
   array_push($ids_array1, $val["id"]);
   $ids_array2 = implode(",", $ids_array3);
   $ids_array4 = implode(",", $ids_array1);

   mysqli_query($connection, "DELETE FROM pbs WHERE id NOT IN ($ids_array2)");
   //mysqli_query($connection, "DELETE FROM pbs WHERE id NOT IN ($ids_array4)");
   
   $check = mysqli_query($connection,"SELECT * FROM `pbs` WHERE `id`='".$val["id"]."'");
   
    if(mysqli_num_rows($check)==1){
        //Update the row
        $sql2 = "UPDATE `pbs` SET `parent`='".$val["parent"]."', `text`='".$val["text"]."' WHERE `id`='".$val["id"]."'";
        $update = mysqli_query($connection, $sql2) or die("Error in Selecting " . mysqli_error($connection));
    }
    else
    {
         $sql = "INSERT INTO pbs(id,parent,text) VALUES('".$val['id']."', '".$val['parent']."', '".$val['text']."')";
    	 $result = mysqli_query($connection, $sql) or die("Error in Selecting " . mysqli_error($connection));
    }
}




mysqli_close($connection);

?> 
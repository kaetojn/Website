<?php
      echo "Sorry you do not have access to this page. Go Back Please. Thank you.";
?>